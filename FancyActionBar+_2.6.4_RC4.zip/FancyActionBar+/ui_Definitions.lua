---@meta doc



---@class Front_Bar_List
---@field desc LabelControl
Front_Bar_List = {};

---@class Back_Bar_List
---@field desc LabelControl
Back_Bar_List = {};

-- ---------------------------------------------------------------------------------------------------------------------
--
---@class FAB_ReadyBurst : TextureControl
FAB_ReadyBurst = TextureControl or {};
-- ---------------------------------------------------------------------------------------------------------------------
--
---@class FAB_KB_Frame : TextureControl
FAB_KB_Frame = TextureControl or {};
-- ---------------------------------------------------------------------------------------------------------------------
--
---@class FAB_BG : BackdropControl
FAB_BG = BackdropControl or {};
-- ---------------------------------------------------------------------------------------------------------------------
--
---@class FAB_Fill : BackdropControl
FAB_Fill = BackdropControl or {};
-- ---------------------------------------------------------------------------------------------------------------------
--
---@class FAB_ActionBar : Control
FAB_ActionBar = Control or {};
-- ---------------------------------------------------------------------------------------------------------------------
--
---@class FAB_Default_Bar_Position : TopLevelWindow
FAB_Default_Bar_Position = TopLevelWindow or {};
-- ---------------------------------------------------------------------------------------------------------------------
--
---@class FAB_QuickSlotOverlay_Keyboard_Template : Control
---@field activeEffects table
---@field timer LabelControl
---@field bg BackdropControl
---@field stack TextureControl
---@field frame TextureControl
---@field effect {id:integer}
FAB_QuickSlotOverlay_Keyboard_Template = Control or {};
-- ---------------------------------------------------------------------------------------------------------------------
--
---@class FAB_QuickSlotOverlay_Gamepad_Template : Control
---@field activeEffects table
---@field timer LabelControl
---@field bg BackdropControl
---@field stack TextureControl
---@field frame TextureControl
---@field effect {id:integer}
FAB_QuickSlotOverlay_Gamepad_Template = Control or {};
-- ---------------------------------------------------------------------------------------------------------------------
--
---@class FAB_UltimateButtonOverlay_Keyboard_Template : Control
---@field effect {id:integer}
FAB_UltimateButtonOverlay_Keyboard_Template = Control or {};
-- ---------------------------------------------------------------------------------------------------------------------
--
---@class FAB_UltimateButtonOverlay_Gamepad_Template : Control
---@field effect {id:integer}
FAB_UltimateButtonOverlay_Gamepad_Template = Control or {};
-- ---------------------------------------------------------------------------------------------------------------------
--
---@class FAB_ActionButtonOverlay_Keyboard_Template : Control
---@field effect {id:integer}
FAB_ActionButtonOverlay_Keyboard_Template = Control or {};
-- ---------------------------------------------------------------------------------------------------------------------
--
---@class FAB_ActionButtonOverlay_Gamepad_Template : Control
---@field effect {id:integer}
FAB_ActionButtonOverlay_Gamepad_Template = Control or {};
-- ---------------------------------------------------------------------------------------------------------------------
--
---@class FAB_GCD : TopLevelWindow
FAB_GCD = TopLevelWindow or {};
-- ---------------------------------------------------------------------------------------------------------------------
--
---@class FAB_Mover : TopLevelWindow
FAB_Mover = TopLevelWindow or {};
-- ---------------------------------------------------------------------------------------------------------------------
--
---@class FAB_ActionBarArrow : TextureControl
FAB_ActionBarArrow = TextureControl or {};
-- ---------------------------------------------------------------------------------------------------------------------
--
---@class FAB_ActionBarFakeQS : TextureControl
FAB_ActionBarFakeQS = TextureControl or {};
-- ---------------------------------------------------------------------------------------------------------------------
--
---@class FAB_QuickSlotOverlay_Keyboard_TemplateFrame : TextureControl
FAB_QuickSlotOverlay_Keyboard_TemplateFrame = TextureControl or {};
-- ---------------------------------------------------------------------------------------------------------------------
--
---@class FAB_QuickSlotOverlay_Keyboard_TemplateDuration : LabelControl
FAB_QuickSlotOverlay_Keyboard_TemplateDuration = LabelControl or {};
-- ---------------------------------------------------------------------------------------------------------------------
--
---@class FAB_QuickSlotOverlay_Gamepad_TemplateDuration : LabelControl
FAB_QuickSlotOverlay_Gamepad_TemplateDuration = LabelControl or {};
-- ---------------------------------------------------------------------------------------------------------------------
--
---@class FAB_UltimateButtonOverlay_Keyboard_TemplateBG : TextureControl
FAB_UltimateButtonOverlay_Keyboard_TemplateBG = TextureControl or {};
-- ---------------------------------------------------------------------------------------------------------------------
--
---@class FAB_UltimateButtonOverlay_Keyboard_TemplateFrame : TextureControl
FAB_UltimateButtonOverlay_Keyboard_TemplateFrame = TextureControl or {};
-- ---------------------------------------------------------------------------------------------------------------------
--
---@class FAB_UltimateButtonOverlay_Keyboard_TemplateDuration : LabelControl
FAB_UltimateButtonOverlay_Keyboard_TemplateDuration = LabelControl or {};
-- ---------------------------------------------------------------------------------------------------------------------
--
---@class FAB_UltimateButtonOverlay_Keyboard_TemplateStacks : LabelControl
FAB_UltimateButtonOverlay_Keyboard_TemplateStacks = LabelControl or {};
-- ---------------------------------------------------------------------------------------------------------------------
--
---@class FAB_UltimateButtonOverlay_Keyboard_TemplateValue : LabelControl
FAB_UltimateButtonOverlay_Keyboard_TemplateValue = LabelControl or {};
-- ---------------------------------------------------------------------------------------------------------------------
--
---@class FAB_UltimateButtonOverlay_Gamepad_TemplateBG : TextureControl
FAB_UltimateButtonOverlay_Gamepad_TemplateBG = TextureControl or {};
-- ---------------------------------------------------------------------------------------------------------------------
--
---@class FAB_UltimateButtonOverlay_Gamepad_TemplateDuration : LabelControl
FAB_UltimateButtonOverlay_Gamepad_TemplateDuration = LabelControl or {};
-- ---------------------------------------------------------------------------------------------------------------------
--
---@class FAB_UltimateButtonOverlay_Gamepad_TemplateStacks : LabelControl
FAB_UltimateButtonOverlay_Gamepad_TemplateStacks = LabelControl or {};
-- ---------------------------------------------------------------------------------------------------------------------
--
---@class FAB_UltimateButtonOverlay_Gamepad_TemplateValue : LabelControl
FAB_UltimateButtonOverlay_Gamepad_TemplateValue = LabelControl or {};
-- ---------------------------------------------------------------------------------------------------------------------
--
---@class FAB_ActionButtonOverlay_Keyboard_TemplateBG : TextureControl
FAB_ActionButtonOverlay_Keyboard_TemplateBG = TextureControl or {};
-- ---------------------------------------------------------------------------------------------------------------------
--
---@class FAB_ActionButtonOverlay_Keyboard_TemplateFrame : TextureControl
FAB_ActionButtonOverlay_Keyboard_TemplateFrame = TextureControl or {};
-- ---------------------------------------------------------------------------------------------------------------------
--
---@class FAB_ActionButtonOverlay_Keyboard_TemplateDuration : LabelControl
FAB_ActionButtonOverlay_Keyboard_TemplateDuration = LabelControl or {};
-- ---------------------------------------------------------------------------------------------------------------------
--
---@class FAB_ActionButtonOverlay_Keyboard_TemplateStacks : LabelControl
FAB_ActionButtonOverlay_Keyboard_TemplateStacks = LabelControl or {};
-- ---------------------------------------------------------------------------------------------------------------------
--
---@class FAB_ActionButtonOverlay_Gamepad_TemplateBG : TextureControl
FAB_ActionButtonOverlay_Gamepad_TemplateBG = TextureControl or {};
-- ---------------------------------------------------------------------------------------------------------------------
--
---@class FAB_ActionButtonOverlay_Gamepad_TemplateDuration : LabelControl
FAB_ActionButtonOverlay_Gamepad_TemplateDuration = LabelControl or {};
-- ---------------------------------------------------------------------------------------------------------------------
--
---@class FAB_ActionButtonOverlay_Gamepad_TemplateStacks : LabelControl
FAB_ActionButtonOverlay_Gamepad_TemplateStacks = LabelControl or {};
-- ---------------------------------------------------------------------------------------------------------------------
--
---@class FAB_MoverBG : BackdropControl
FAB_MoverBG = BackdropControl or {};
-- ---------------------------------------------------------------------------------------------------------------------
--
---@class FAB_AB_Move : ButtonControl
---@field button LabelControl
FAB_AB_Move = ButtonControl or {};

---@class SkillToBlacklistTitle
---@field desc LabelControl

---@class SkillToEditTitle
---@field desc LabelControl

---@class SkillToBlacklistID_Editbox
---@field editbox EditControl

---@class Blacklist_Dropdown : LibAddonMenu2
---@field dropdown ZO_ComboBox_Base

---@class EffectToTrackTitle
---@field desc LabelControl

---@class Change_Type_Dropdown : LibAddonMenu2
---@field dropdown ZO_ComboBox_Base

---@class Saved_Changes_Dropdown : LibAddonMenu2
---@field dropdown ZO_ComboBox_Base

---@class SkillToEditID_Editbox
---@field editbox EditControl

---@class EffectToTrackID_Editbox
---@field editbox EditControl

---@class FAB_AB_Toggle
---@field button LabelControl