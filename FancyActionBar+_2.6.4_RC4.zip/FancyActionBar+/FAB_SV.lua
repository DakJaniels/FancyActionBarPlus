---@class FAB_AC_SV
FAB_AC_SV =
{
  qsYGP = 0;
  ultValueXKB = -2;
  perfectWeave = true;
  ultXGP = 25;
  ultYKB = 0;
  ultColorGP =
  {
    [1] = 1;
    [2] = 1;
    [3] = 1;
  };
  qsNameKB = "Univers 67";
  ultFlash = true;
  ultValueModeKB = 2;
  gcd =
  {
    sizeY = 50;
    sizeX = 50;
    y = 1000;
    combatOnly = false;
    enable = false;
    fillColor =
    {
      [4] = 1;
      [1] = 0.2000000000;
      [2] = 0.6000000000;
      [3] = 1;
    };
    x = 1000;
    frameColor =
    {
      [4] = 1;
      [1] = 0;
      [2] = 0;
      [3] = 0;
    };
  };
  qsYKB = 10;
  fontTypeGP = "thick-outline";
  durationMin = 2;
  keepLastTarget = true;
  ultNameGP = "Univers 67";
  fontNameKB = "Univers 67";
  ultValueModeGP = 1;
  showExpireStart = 2;
  debuffTable =
  {
    [31104] = true;
    [44373] = true;
    [126374] = true;
    [61723] = true;
  };
  ultValueTypeKB = "outline";
  fontNameStackKB = "Univers 67";
  debug = false;
  ultValueCompanionXKB = 0;
  highlightColor =
  {
    [4] = 0.7000000000;
    [1] = 0;
    [2] = 1;
    [3] = 0;
  };
  showExpire = true;
  qsXGP = 10;
  frontBarTop = true;
  ultShowGP = true;
  fadeDelay = 2;
  moveQS = true;
  fontNameStackGP = "Univers 67";
  lockInTrade = false;
  ultValueEnableCompanionKB = false;
  fontTypeStackGP = "thick-outline";
  ultValueYKB = -5;
  frameColor =
  {
    [4] = 1;
    [1] = 0;
    [2] = 0;
    [3] = 0;
  };
  stackXKB = 37;
  ultValueCompanionYGP = 0;
  showHighlight = true;
  ultValueSizeKB = 20;
  delayFade = true;
  ultValueModeCompanionGP = 1;
  expireColor =
  {
    [1] = 1;
    [2] = 1;
    [3] = 0;
  };
  highlightExpire = true;
  hideOnNoTargetGlobal = false;
  ultValueColorKB =
  {
    [1] = 1;
    [2] = 1;
    [3] = 1;
  };
  abScaling =
  {
    gp =
    {
      scale = 100;
      enable = false;
    };
    kb =
    {
      scale = 100;
      enable = true;
    };
  };
  qsSizeKB = 24;
  showHotkeys = false;
  qsTypeGP = "outline";
  timeColorGP =
  {
    [1] = 1;
    [2] = 1;
    [3] = 1;
  };
  ultSizeKB = 24;
  ultColorKB =
  {
    [1] = 1;
    [2] = 1;
    [3] = 1;
  };
  qsTimerEnableKB = false;
  ultValueSizeGP = 22;
  showFrames = true;
  qsTypeKB = "outline";
  ultValueColorGP =
  {
    [1] = 1;
    [2] = 1;
    [3] = 1;
  };
  showArrow = true;
  abMove =
  {
    gp =
    {
      prevY = 0;
      enable = true;
      y = -75;
      prevX = 0;
      x = 0;
    };
    kb =
    {
      prevY = 1059.5999755859;
      enable = true;
      y = 929.5999755859;
      prevX = 702.5000000000;
      x = 715;
    };
  };
  qsSizeGP = 34;
  activeBarTop = false;
  ultValueEnableKB = false;
  showDecimalStart = 2;
  alphaInactive = 90;
  ultTypeKB = "thick-outline";
  ultShowKB = false;
  ultValueXGP = 0;
  qsColorKB =
  {
    [1] = 1;
    [2] = 0.5000000000;
    [3] = 0.2000000000;
  };
  qsXKB = 0;
  externalBuffs = true;
  arrowColor =
  {
    [4] = 1;
    [1] = 0;
    [2] = 1;
    [3] = 0;
  };
  staticBars = true;
  fontSizeStackGP = 22;
  markerSize = 36;
  stackColorKB =
  {
    [1] = 1;
    [2] = 0.8000000000;
    [3] = 0;
  };
  ultValueEnableGP = false;
  debugVerbose = false;
  desaturationInactive = 10;
  advancedDebuff = true;
  highlightExpireColor =
  {
    [4] = 0.7000000000;
    [1] = 1;
    [2] = 0;
    [3] = 0;
  };
  ultValueCompanionXGP = 0;
  noTargetFade = false;
  fontNameGP = "Univers 67";
  stackXGP = 37;
  externalBlackListRun = true;
  noTargetAlpha = 90;
  ultValueModeCompanionKB = 1;
  ultTypeGP = "thick-outline";
  qsColorGP =
  {
    [1] = 1;
    [2] = 0.5000000000;
    [3] = 0.2000000000;
  };
  toggledHighlight = true;
  toggledColor =
  {
    [4] = 0.7000000000;
    [1] = 1;
    [2] = 1;
    [3] = 1;
  };
  ultValueCompanionYKB = 0;
  debuffConfigUpgraded = false;
  showDecimal = "Expire";
  fontSizeGP = 34;
  timeYGP = 0;
  ultNameKB = "Univers 67";
  fontTypeKB = "thick-outline";
  variablesValidated = true;
  qsTimerEnableGP = true;
  showHotkeysUltGP = true;
  hideOnNoTargetList =
  {
  };
  ultSizeGP = 40;
  ultValueNameGP = "Univers 67";
  hideDefaultFrames = false;
  fontSizeKB = 24;
  ultYGP = 0;
  ultValueYGP = 0;
  fontSizeStackKB = 20;
  stackColorGP =
  {
    [1] = 1;
    [2] = 0.8000000000;
    [3] = 0;
  };
  configChanges =
  {
  };
  showDeath = false;
  timeYKB = 0;
  dynamicAbilityConfig = true;
  externalBlackList =
  {
    [61504] = "Vigor";
    [28385] = "Grand Healing";
    [40130] = "Ward Ally";
    [61665] = "Major Brutality";
    [76518] = "Major Brutality";
    [61694] = "Major Resolve";
    [29224] = "Igneous Shield";
    [61693] = "Minor Resolve";
    [83850] = "Life Giver";
    [31531] = "Force Siphon";
    [85132] = "Lights Champion";
    [40109] = "Siphon Spirit";
    [61704] = "Minor Endurance";
    [61706] = "Minor Intellect";
    [37232] = "Steadfast Ward";
    [61697] = "Minor Fortitude";
    [61506] = "Echoing Vigor";
    [28536] = "Regeneration";
    [40116] = "Quick Siphon";
    [92503] = "Major Sorcery";
    [88758] = "Major Resolve";
    [61687] = "Major Sorcery";
    [38552] = "Panacea";
    [61721] = "Minor Protection";
    [40058] = "Illustrious Healing";
    [40076] = "Rapid Regeneration";
    [40060] = "Healing Springs";
    [186493] = "Minor Protection";
    [40126] = "Healing Ward";
    [176991] = "Minor Resolve";
  };
  durationMax = 120;
  ultValueNameKB = "Univers 67";
  ultValueEnableCompanionGP = true;
  fontTypeStackKB = "thick-outline";
  ultXKB = 37;
  showMarker = false;
  version = 1;
  timeColorKB =
  {
    [1] = 1;
    [2] = 1;
    [3] = 1;
  };
  ultValueTypeGP = "outline";
  qsNameGP = "Univers 67";
  debugAll = false;
};

---@class FAB_DC_SV
FAB_DC_SV =
{
  configChanges = {};
  dynamicAbilityConfig = true;
  version = 1;
  noTargetFade = false;
  hideOnNoTargetList = {};
  LastCharacterName = "CharacterName";
  hideOnNoTargetGlobal = false;
  noTargetAlpha = 90;
  debuffConfigUpgraded = false;
  useAccountWide = true;
};
---@class FAB_defaultSettings
FAB_defaultSettings = {
  variablesValidated = false;
  -- ability tracking

  configChanges = {};
  dynamicAbilityConfig = false;

  externalBuffs = false;
  externalBlackList = {};
  externalBlackListRun = false;

  advancedDebuff = false;
  keepLastTarget = true;
  debuffConfigUpgraded = false;

  hideOnNoTargetGlobal = false;
  hideOnNoTargetList = {};

  noTargetFade = false;
  noTargetAlpha = 90;

  durationMin = 2;
  durationMax = 120;

  -- general
  lockInTrade = true;
  staticBars = true;
  frontBarTop = true;
  activeBarTop = false;
  -- hideInactive									= false,
  showHotkeys = true;
  showHotkeysUltGP = true;
  showHighlight = true;
  highlightColor = { 0; 1; 0; 0.7 };
  highlightExpire = false;
  highlightExpireColor = { 1; 0; 0; 0.7 };
  toggledHighlight = false;
  toggledColor = { 1; 1; 1; 0.7 };
  -- back bar visibility
  alphaInactive = 20;
  desaturationInactive = 50;
  -- timer display settings
  delayFade = true;
  fadeDelay = 2;
  showDecimal = "Expire";
  showDecimalStart = 2;
  showExpire = true;
  showExpireStart = 2;
  expireColor = { 1; 1; 0 };
  -- keyboard UI visuals
  -- duration
  fontNameKB = "Univers 67";
  fontSizeKB = 24;
  fontTypeKB = "thick-outline";
  timeYKB = 0;
  timeColorKB = { 1; 1; 1 };
  -- stacks
  fontNameStackKB = "Univers 67";
  fontSizeStackKB = 20;
  fontTypeStackKB = "thick-outline";
  stackXKB = 37;
  stackColorKB = { 1; 0.8; 0 };
  -- ult duration
  ultShowKB = true;
  ultNameKB = "Univers 67";
  ultSizeKB = 24;
  ultTypeKB = "thick-outline";
  ultXKB = 37;
  ultYKB = 0;
  ultColorKB = { 1; 1; 1 };
  -- ult value
  ultValueEnableKB = false;
  ultValueModeKB = 1;
  ultValueNameKB = "Univers 67";
  ultValueSizeKB = 20;
  ultValueTypeKB = "outline";
  ultValueXKB = -2;
  ultValueYKB = -5;
  ultValueColorKB = { 1; 1; 1 };
  -- companion
  ultValueEnableCompanionKB = true;
  ultValueModeCompanionKB = 1;
  ultValueCompanionXKB = 0;
  ultValueCompanionYKB = 0;
  -- quick slot
  qsTimerEnableKB = true;
  qsNameKB = "Univers 67";
  qsSizeKB = 24;
  qsTypeKB = "outline";
  qsXKB = 0;
  qsYKB = 10;
  qsColorKB = { 1; 0.5; 0.2 };
  -- gamepad UI visuals
  -- duration
  fontNameGP = "Univers 67";
  fontSizeGP = 34;
  fontTypeGP = "thick-outline";
  timeYGP = 0;
  timeColorGP = { 1; 1; 1 };
  -- stacks
  fontNameStackGP = "Univers 67";
  fontSizeStackGP = 22;
  fontTypeStackGP = "thick-outline";
  stackXGP = 37;
  stackColorGP = { 1; 0.8; 0 };
  -- ult
  ultShowGP = true;
  ultNameGP = "Univers 67";
  ultSizeGP = 40;
  ultTypeGP = "thick-outline";
  ultXGP = 25;
  ultYGP = 0;
  ultColorGP = { 1; 1; 1 };
  -- ult value
  ultValueEnableGP = false;
  ultValueModeGP = 1;
  ultValueNameGP = "Univers 67";
  ultValueSizeGP = 22;
  ultValueTypeGP = "outline";
  ultValueXGP = 0;
  ultValueYGP = 0;
  ultValueColorGP = { 1; 1; 1 };
  -- companion
  ultValueEnableCompanionGP = true;
  ultValueModeCompanionGP = 1;
  ultValueCompanionXGP = 0;
  ultValueCompanionYGP = 0;
  -- quick slot
  qsTimerEnableGP = true;
  qsNameGP = "Univers 67";
  qsSizeGP = 34;
  qsTypeGP = "outline";
  qsXGP = 10;
  qsYGP = 0;
  qsColorGP = { 1; 0.5; 0.2 };
  -- both
  ultFlash = true;
  -- frames for keyboard UI
  showFrames = true;
  frameColor = { 0; 0; 0; 1 };
  hideDefaultFrames = false;
  -- arrow and quick slot display style
  showArrow = true;
  arrowColor = { 0; 1; 0; 1 };
  moveQS = true;
  -- enemy markers
  showMarker = false;
  markerSize = 26;
  -- global cooldown tracker
  gcd = {
    enable = false;
    combatOnly = false;
    x = 1000;
    y = 1000;
    sizeX = 50;
    sizeY = 50;
    fillColor = { 0.2; 0.6; 1; 1 };
    frameColor = { 0; 0; 0; 1 };
  };
  -- action bar scale and position
  abScaling = {
    kb = { enable = false; scale = 100 };
    gp = { enable = false; scale = 100 };
  };
  abMove = {                                                       -- y = -(default + adjusted) anchor offset
    kb = { enable = false; x = 0; y = -22; prevX = 0; prevY = 0 }; -- y =      -( 0 + 22)
    gp = { enable = false; x = 0; y = -75; prevX = 0; prevY = 0 }; -- y =      -(25 + 52)
  };
  showDeath = false;
  -- compatibility
  perfectWeave = false;
  -- debug
  debug = false;
  debugAll = false;
  debugVerbose = false;
};
